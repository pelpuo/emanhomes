AdminBro.UserComponents = {}
import Component1 from '../components/upload-image.edit'
AdminBro.UserComponents.Component1 = Component1
import Component2 from '../components/upload-image.list'
AdminBro.UserComponents.Component2 = Component2
import Component3 from '../components/upload-image.edit'
AdminBro.UserComponents.Component3 = Component3
import Component4 from '../components/upload-image.list'
AdminBro.UserComponents.Component4 = Component4
import Component5 from '../components/upload-image.edit'
AdminBro.UserComponents.Component5 = Component5
import Component6 from '../components/upload-image.list'
AdminBro.UserComponents.Component6 = Component6
import Component7 from '../components/upload-image.edit'
AdminBro.UserComponents.Component7 = Component7
import Component8 from '../components/upload-image.list'
AdminBro.UserComponents.Component8 = Component8
import Component9 from '../components/upload-image.edit'
AdminBro.UserComponents.Component9 = Component9
import Component10 from '../components/upload-image.list'
AdminBro.UserComponents.Component10 = Component10
import Component11 from '../components/upload-image.edit'
AdminBro.UserComponents.Component11 = Component11
import Component12 from '../components/upload-image.list'
AdminBro.UserComponents.Component12 = Component12
import Component13 from '../components/upload-image.edit'
AdminBro.UserComponents.Component13 = Component13
import Component14 from '../components/upload-image.list'
AdminBro.UserComponents.Component14 = Component14
import Component15 from '../components/dashboard'
AdminBro.UserComponents.Component15 = Component15